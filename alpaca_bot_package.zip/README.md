
# Alpaca Momentum Bot

This trading bot uses a momentum and volatility filter to trade SPY and QQQ through the Alpaca API.

## Deployment (Railway)
1. Create a new Railway project and upload these files.
2. Set environment variables:
    - `API_KEY`
    - `SECRET_KEY`
    - `BASE_URL` = https://paper-api.alpaca.markets
3. Add a cron job (plugin) to run:
    - Schedule: `0 15 * * 1-5` (daily at 11 AM EST)
    - Command: `python alpaca_trading_bot.py`
